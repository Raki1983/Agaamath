AGAA-MATH Learning App - Starter build

RUN LOCALLY:
1. Extract this ZIP.
2. Open a terminal in the extracted folder.
3. Run: python -m http.server 8000
4. Visit http://localhost:8000

PUBLISH FREE:
- Upload the extracted folder to a static hosting provider such as GitHub Pages or Cloudflare Pages.
- Use HTTPS for PWA installation and service-worker support.
- This is a PWA website that can be installed from a supported Android browser.
- Google Play Store publication is separate and may involve developer registration and packaging requirements.

CUSTOMISE:
- Open app.js.
- Set YOUTUBE_PLAYLIST_ID to the ID of your public YouTube playlist.
- Add worksheet entries to WORKSHEETS and place PDF files in a worksheets folder.
- Update GRADE_TOPICS with your curriculum-specific topic lists.
- The included calculator is basic arithmetic only; the AI math solver is not connected yet.

IMPORTANT:
- No student login, cloud sync, admin dashboard, or server-side database is included in this first prototype.
- Avoid collecting children's personal data until privacy, consent, and security requirements are implemented.
